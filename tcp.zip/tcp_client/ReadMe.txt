
  o--------------------o
  | TCP client Example |
  o--------------------o

  Compatible platforms
  --------------------
  * Connect WAN 3G IA
  * ConnectCore 3G 9P 9215
  * ConnectPort WAN GPS
  * ConnectPort WAN VPN
  * ConnectPort WAN Wi
  * ConnectPort X2
  * ConnectPort X2 SE
  * ConnectPort X2B
  * ConnectPort X2D
  * ConnectPort X2e Wi-Fi ZB
  * ConnectPort X2e ZB
  * ConnectPort X2e ZB EVDO Verizon
  * ConnectPort X2e ZB HSPA
  * ConnectPort X2e ZB UMTS
  * ConnectPort X2e ZB Wi-Fi
  * ConnectPort X4 (current)
  * ConnectPort X4 4G
  * ConnectPort X4 H
  * ConnectPort X4 IA
  * ConnectPort X4 NEMA
  * ConnectPort X5
  * ConnectPort X5 F
  * ConnectPort X5 F ZB GPRS
  * ConnectPort X5 F ZB Wifi GPRS
  * ConnectPort X5 R
  * ConnectPort X5 R Wifi GPRS Iridium
  * ConnectPort X5 R ZB GPRS
  * ConnectPort X5 R ZB Wifi CDMA
  * ConnectPort X5 R ZB Wifi GPRS
  * ConnectPort X8
  * Digi Connect SP Python
  * Digi Connect Wi-SP 16M Python
  * Embedded Gateway
  * TransPort WR21
  * TransPort WR41
  * TransPort WR41v2
  * TransPort WR44
  * TransPort WR44RR
  * TransPort WR44v2
  * XBee Gateway
  * XBee Gateway EVDO Sprint
  * XBee Gateway EVDO Verizon
  * XBee Gateway HSPA
  * XBee Gateway UMTS
  * XBee Gateway Wi-Fi

  Introduction
  ------------
  This example declares a TCP socket, connects with a remote TCP server and 
  sends a "Hello world" message.

  Requirements
  ------------
  To run this example you will need:
    * One Digi Python compatible device to host the application.
    * A remote TCP echo server to send the data back to the example. 
        NOTE: You can use the "Simple TCP server" example and run it locally 
        instead of in the remote Digi device.
        
  This example requires the Connection Mode = Local Area Network/USB/Serial 
  under the Device Manager�s General Tab.

  Example setup
  -------------
  1) Make sure the hardware is set up correctly:
       a) The Digi device is powered on.
       b) The Digi device is connected directly to the PC or to the Local 
          Area Network (LAN) by the Ethernet cable. In case the device does 
          not have Ethernet interface, make sure it is connected directly to 
          the PC by the corresponding USB or serial cable.
     
  2) You need to edit the following lines of code in the example:
     
       HOST = '0.0.0.0' 
       PORT = 5000
     
     You must enter the IP Address of the remote TCP server and the port 
     where the server is listening. Then, save the file.

  Running the example
  -------------------
  The example is already configured, so all you need to do is to build and 
  launch the project.
  
  While it is running, the Digi device will send a "Hello World" message to 
  the TCP server running at the configured IP and port. If there is an echo 
  TCP server running there, you should receive the following message:
  
    Received 'Hello, world'

  Tested On
  ---------
  ConnectPort X2e ZB
  ConnectPort X3
  ConnectPort X4
  TransPort WR21
  TransPort WR44
  XBee Gateway

